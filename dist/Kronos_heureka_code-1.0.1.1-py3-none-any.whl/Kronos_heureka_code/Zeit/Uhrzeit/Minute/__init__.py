from Kronos_heureka_code.Zeit.Uhrzeit.Minute.MinuteException import \
    MinuteException, \
    MinuteZuKlein, \
    MinuteZuGross, \
    MinuteKeineGanzeZahl
from Kronos_heureka_code.Zeit.Uhrzeit.Minute.Minute import Minute
