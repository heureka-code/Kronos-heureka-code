from Kronos_heureka_code.Zeit.Uhrzeit.Sekunde.SekundeException import \
    SekundeException, \
    SekundeZuGross, \
    SekundeZuKlein, \
    SekundeKeineGanzeZahl
from Kronos_heureka_code.Zeit.Uhrzeit.Sekunde.Sekunde import Sekunde
