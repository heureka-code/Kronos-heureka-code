from Kronos_heureka_code.Zeit.ZeitException import ZeitException


class UhrzeitException(ZeitException):
    pass
