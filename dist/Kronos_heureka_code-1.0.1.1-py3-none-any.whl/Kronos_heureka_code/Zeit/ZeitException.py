from Kronos_heureka_code.KronosException import KronosException


class ZeitException(KronosException):
    pass
