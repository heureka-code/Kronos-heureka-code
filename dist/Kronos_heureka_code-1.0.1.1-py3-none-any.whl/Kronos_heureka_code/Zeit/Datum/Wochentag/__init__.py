from Kronos_heureka_code.Zeit.Datum.Wochentag.Wochentag import Wochentag, Wochentage
from Kronos_heureka_code.Zeit.Datum.Wochentag.WochentagException import \
    WochentagException, \
    UngueltigerWochentagname, \
    UngueltigeWochentagposition
