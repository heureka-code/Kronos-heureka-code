from Kronos_heureka_code.Notationen.UhrzeitNotationen import *
from Kronos_heureka_code.Notationen.DatumsNotationen import *
