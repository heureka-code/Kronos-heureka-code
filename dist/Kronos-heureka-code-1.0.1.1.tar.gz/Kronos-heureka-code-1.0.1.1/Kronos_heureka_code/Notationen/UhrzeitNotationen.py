from Kronos_heureka_code.Zeit.Uhrzeit.Uhrzeit import \
    HMS, HMS_DOT, HMS_DASH, HMS_SLASH, HMS_COLON, \
    SMH, SMH_DASH, SMH_DOT, SMH_SLASH, SMH_COLON, \
    SSMMHH, SSMMHH_NON_SPLITTED, \
    HHMMSS, HHMMSS_NON_SPLITTED
