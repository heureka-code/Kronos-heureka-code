from Kronos_heureka_code.Zeit.Datum.Datum import \
    JMT, JMT_DOT, JMT_DASH, JMT_SLASH, \
    TMJ, TMJ_DASH, TMJ_DOT, TMJ_SLASH, \
    TTMMJJJJ, TTMMJJJJ_NON_SPLITTED, \
    JJJJMMTT_NON_SPLITTED, JJJJMMTT
