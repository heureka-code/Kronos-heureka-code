from Kronos_heureka_code.Zeit.Uhrzeit.Stunde.StundeException import \
    StundeException, \
    StundeZuKlein, \
    StundeZuGross, \
    StundeKeineGanzeZahl
from Kronos_heureka_code.Zeit.Uhrzeit.Stunde.Stunde import Stunde
