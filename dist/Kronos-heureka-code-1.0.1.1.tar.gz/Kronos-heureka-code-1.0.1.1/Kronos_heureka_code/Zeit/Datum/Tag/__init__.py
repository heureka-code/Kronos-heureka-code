from Kronos_heureka_code.Zeit.Datum.Tag.TagException import \
    TagException, \
    TagZuGross, \
    TagKeineGanzeZahl, \
    TagKleinerAlsEins
from Kronos_heureka_code.Zeit.Datum.Tag.Tag import Tag
